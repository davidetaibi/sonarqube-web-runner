#!/bin/sh

while test "notempty"
do
  sleep 1
done
