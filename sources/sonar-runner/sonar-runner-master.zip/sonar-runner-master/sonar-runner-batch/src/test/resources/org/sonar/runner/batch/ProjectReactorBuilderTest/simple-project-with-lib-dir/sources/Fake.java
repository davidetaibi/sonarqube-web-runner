package org.sonar.runner.batch.ProjectReactorBuilderTest.simple

Fake